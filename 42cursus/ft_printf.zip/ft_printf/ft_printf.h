/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin@42.fr <tkathrin>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/09 19:06:22 by tkathrin          #+#    #+#             */
/*   Updated: 2020/11/12 10:48:25 by marvin@42.f      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <stdlib.h>
# include <unistd.h>
# include "libft.h"


typedef struct	s_tab
{
	int			dot;
	int			zero;
	int			minus;
	int			star;
	int			width;					/* "*." */
	int			precision;				/* ".*" */
	int			type;					/* cspdiuxX% */
	int			length;					/* count */
}				t_tab;

int				ft_printf(const char *format, ...);
int				prf_parser(const char *format, va_list args);
int				prf_percent(char *str, int n);
int				prf_flags(const char *format, int i, t_tab *tab, va_list args);
t_tab			prf_flag_minus(t_tab tab);
t_tab			prf_flag_digit(char c, t_tab tab);
t_tab			prf_flag_width(va_list args, t_tab tab);

int				prf_parse_char(int c, t_tab tab);
int				prf_parse_string(char *str, t_tab tab);


#endif
