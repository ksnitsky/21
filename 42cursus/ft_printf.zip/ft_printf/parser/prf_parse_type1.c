#include "ft_printf.h"

int		prf_parse_char(int c, t_tab tab)
{
	int count;

	count = 0;
	if (tab.minus == 1)
		count += ft_putchar(c);
	count += tab.width;
	return (count);
}

int		prf_parse_string(char *str, t_tab tab)
{
	int count;

	count = 0;

	while (str[count] != '\0')
		write(1, &str[count++], 1);
		

	return (count);
}
